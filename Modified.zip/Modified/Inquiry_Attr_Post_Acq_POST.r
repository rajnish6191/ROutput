# State of Execution
print(Sys.time())
memory.limit(8000)

#Load Libraries

library(data.table)
library(plyr)
library(dplyr)
library(stringr)
library(splitstackshape)
library(lazyeval)
library(rstudioapi)
library(tcltk)
library(Rserve)
Rserve()


##the function that returns the path of the script that is called.
##used to determine the path of the executing program
get_scriptpath <- function() {
  # location of script can depend on how it was invoked:
  # source() and knit() put it in sys.calls()
  path <- NULL
  
  if(!is.null(sys.calls())) {
    # get name of script - hope this is consisitent!
    path <- as.character(sys.call(1))[2] 
    # make sure we got a file that ends in .R, .Rmd or .Rnw
    if (grepl("..+\\.[R|Rmd|Rnw]", path, perl=TRUE, ignore.case = TRUE) )  {
      return(path)
    } else { 
      message("Obtained value for path does not end with .R, .Rmd or .Rnw: ", path)
    }
  } else{	
    # Rscript and R -f put it in commandArgs
    args <- commandArgs(trailingOnly = FALSE)
  }
  return(path)
}

##find the script path
mypath <- get_scriptpath()

##get the current path, set it and navigate to download folder to get ready to read the files
DIR <- dirname(mypath)
setwd(DIR)
setwd("..")
setwd(".//download")

## opens the dialogue window to select output 
output_loc <- tk_choose.dir(getwd(),"Please choose the location to save the output files.")


##function to create the UI for determining the output name
varEntryDialog <- function(vars,
                           labels = vars,
                           fun = rep(list(as.character), length(vars)),
                           title = 'Variable Entry',
                           prompt = NULL) {
  require(tcltk)
  stopifnot(length(vars) == length(labels), length(labels) == length(fun))
  # Create a variable to keep track of the state of the dialog window:
  # done = 0; If the window is active
  # done = 1; If the window has been closed using the OK button
  # done = 2; If the window has been closed using the Cancel button or destroyed
  done <- tclVar(0)
  tt <- tktoplevel()
  tkwm.title(tt, title)
  entries <- list()
  tclvars <- list()
  # Capture the event "Destroy" (e.g. Alt-F4 in Windows) and when this happens,
  # assign 2 to done.
  tkbind(tt,"<Destroy>",function() tclvalue(done)<-2)
  for(i in seq_along(vars)) {
    tclvars[[i]] <- tclVar("Inquiry_Post.csv")
    entries[[i]] <- tkentry(tt, textvariable=tclvars[[i]])
  }
  doneVal <- as.integer(tclvalue(done))
  results <- list()
  reset <- function() {
    for(i in seq_along(entries)) {
      tclvalue(tclvars[[i]]) <<- ""
    }
  }
  reset.but <- tkbutton(tt, text="Reset", command=reset)
  cancel <- function() {
    tclvalue(done) <- 2
  }
  cancel.but <- tkbutton(tt, text='Cancel', command=cancel)
  submit <- function() {
    for(i in seq_along(vars)) {
      tryCatch( {
        results[[vars[[i]]]] <<- fun[[i]](tclvalue(tclvars[[i]]))
        tclvalue(done) <- 1
      },
      error = function(e) { tkmessageBox(message=geterrmessage()) },
      finally = { }
      )
    }
  }
  submit.but <- tkbutton(tt, text="Submit", command=submit)
  if(!is.null(prompt)) {
    tkgrid(tklabel(tt,text=prompt), columnspan=3, pady=5)
  }
  for(i in seq_along(vars)) {
    tkgrid(tklabel(tt, text=labels[i]), entries[[i]], pady=10, padx=10, columnspan=4)
  }
  tkgrid(submit.but, cancel.but, reset.but, pady=10, padx=10, columnspan=3)
  tkfocus(tt)
  # Do not proceed with the following code until the variable done is non-zero.
  # (But other processes can still run, i.e. the system is not frozen.)
  tkwait.variable(done)
  if(tclvalue(done) != 1) {
    results <- NULL
  }
  tkdestroy(tt)
  return(results)
}

##execute the function and set the output nname
var1 <- varEntryDialog(vars = 'Name', title = 'Output file name', prompt = 'Input name of the output file:')
output_name <- var1$Name




#Input Data

##reads in the intial file to determine the number of rows that we will need to loop through to execute. 
for(i in 1:length(list.files())){
  if(tools::file_ext(list.files()[i])== "csv"){
    file <- read.csv(list.files()[i], sep="|",header=T,colClasses=c("CANDIDATE...ID"="character","LOS.APP.ID"="character"), nrows = 1)
    if((ncol(file) == 42 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
       (ncol(file) == 41 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
       (ncol(file) == 43 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") |
       (ncol(file) == 40 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID")){
            
      dz <- read.csv(list.files()[i], sep="|",header=T,colClasses=c("NULL", NA,"NULL","NULL","NULL","NULL","NULL","NULL","NULL",
                                                                    "NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL",
                                                                    "NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL",
                                                                    "NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL",
                                                                    "NULL","NULL","NULL","NULL","NULL"), row.names = NULL)
      dy <- read.csv(list.files()[i], sep="|",header=T,colClasses=c("CANDIDATE...ID"="character","LOS.APP.ID"="character"), row.names = NULL, nrows = 1)

      #d <- read.csv(list.files()[i], sep="|",header=T,colClasses=c("CANDIDATE...ID"="character","LOS.APP.ID"="character"))
      rm(file)
      break
    } else if (i == length(list.files())){
      print("No Account file found!!")
    }
  }
}


#df<-read.table("D:/Script/Post_Acq/Inquiry_Post_Acq.csv",sep="|",header=T,fill=T)
for(i in 1:length(list.files())){
  if(tools::file_ext(list.files()[i])== "csv"){
    file <- read.csv(list.files()[i], sep="|",header=T, nrows = 1,colClasses=c("LOS.APP.ID"="character"))
    if((ncol(file) == 32 & colnames(file)[2] == "LOS.APP.ID" & colnames(file)[3] == "BRANCH.ID") | 
       (ncol(file) == 33 & colnames(file)[2] == "LOS.APP.ID" & colnames(file)[3] == "BRANCH.ID") |
       (ncol(file) == 31 & colnames(file)[2] == "LOS.APP.ID" & colnames(file)[3] == "BRANCH.ID")){
      
      df <- read.csv(list.files()[i], sep="|",header=T,fill=T)
      rm(file)
      break
    } else if (i == length(list.files())){
      print("No Inquiry file found!!")
    }
  }
}
df$X<-NULL

#df1<-read.table("D:/Script/Post_Acq/Ioi_Post_Acq.csv",sep="|",header=T)
for(i in 1:length(list.files())){
  if(tools::file_ext(list.files()[i])== "csv"){
    file <- read.csv(list.files()[i], sep="|",header=T, nrows = 1,colClasses=c("LOS.APP.ID"="character"))
    if((ncol(file) == 10 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")|
       (ncol(file) == 9 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")|
       (ncol(file) == 11 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")){
      
      df2 <- read.csv(list.files()[i], sep="|",header=T,colClasses=c("LOS.APP.ID"="character"),fill=T)
      rm(file)
      break
    } else if (i == length(list.files())){
      print("No Summary file found!!")
    }
  }
}
df2$X<-NULL

#df2<-read.table("D:/Script/Post_Acq/Summary_Post_Acq.csv",sep="|",header=T)
for(i in 1:length(list.files())){
  if(tools::file_ext(list.files()[i])== "csv"){
    file <- read.csv(list.files()[i], sep="|",header=T, nrows = 1,colClasses=c("LOS.APP.ID"="character"))
    if((ncol(file) == 28 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")|
       (ncol(file) == 27 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")|
       (ncol(file) == 26 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")){
      
      df1 <- read.csv(list.files()[i], sep="|",header=T)
      rm(file)
      break
    } else if (i == length(list.files())){
      print("No Ioi file found!!")
    }
  }
}
df1$X<-NULL

##finds the column name and row number and records them
rownumber <- nrow(dz)
column.names <- colnames(dy)

## drops the whole data.frame so we will free up RAM to start execution.
rm(dz)
rm(dy)
gc()



k<-function(d)
{
##agragates data into a table from all account statuses
all_trades<-function(data.frame,ACCOUNT.STATUS)
{
act<-aggregate(d$ACCOUNT.STATUS,list(crd=d$CREDT.RPT.ID),table)
colnames(act) <- c("CREDT.RPT.ID", "ALL_TYPES_TRADES")
return(act)
}
ALL_TRADES<-all_trades(d,ACCOUNT.STATUS)

##agragates data into a table from all account statuses
all_trades_types<-function(data.frame)
{
act<-aggregate(d$ACCT.TYPE,list(crd=d$CREDT.RPT.ID),table)
colnames(act) <- c("CREDT.RPT.ID", "TRADES")
return(act)
}
PDT_TYPE<-all_trades_types(d)


pcblgtthreethousand<-function(d)
{
pclgt3k<-function(d)
{




## returns 1 if column x is larger than 30 and y is larger than 3000, 0 otherwise
clgt3k<-function(x,y)
{
c<-ifelse(x>30&y>3000,1,0) 
return(c)
}
c1<-clgt3k(d$DPD...HIST_01,d$CUR.BAL...HIST_01)
c2<-clgt3k(d$DPD...HIST_02,d$CUR.BAL...HIST_02)
c3<-clgt3k(d$DPD...HIST_03,d$CUR.BAL...HIST_03)
c4<-clgt3k(d$DPD...HIST_04,d$CUR.BAL...HIST_04)
c5<-clgt3k(d$DPD...HIST_05,d$CUR.BAL...HIST_05)
c6<-clgt3k(d$DPD...HIST_06,d$CUR.BAL...HIST_06)
c7<-clgt3k(d$DPD...HIST_07,d$CUR.BAL...HIST_07)
c8<-clgt3k(d$DPD...HIST_08,d$CUR.BAL...HIST_08)
c9<-clgt3k(d$DPD...HIST_09,d$CUR.BAL...HIST_09)
c10<-clgt3k(d$DPD...HIST_10,d$CUR.BAL...HIST_10)
c11<-clgt3k(d$DPD...HIST_11,d$CUR.BAL...HIST_11)
c12<-clgt3k(d$DPD...HIST_12,d$CUR.BAL...HIST_12)
c1[is.na(c1)]<-0
c2[is.na(c2)]<-0
c3[is.na(c3)]<-0
c4[is.na(c4)]<-0
c5[is.na(c5)]<-0
c6[is.na(c6)]<-0
c7[is.na(c7)]<-0
c8[is.na(c8)]<-0
c9[is.na(c9)]<-0
c10[is.na(c10)]<-0
c11[is.na(c11)]<-0 
c12[is.na(c12)]<-0

q<-c1+c2+c3+c4+c5+c6+c7+c8+c9+c10+c11+c12
return(q)
}

## sums the values in CREDT.RPT.ID columns
d$gtthree<-pclgt3k(d)
act<-aggregate(d$gtthree,list(crd=d$CREDT.RPT.ID),sum) 
colnames(act) <- c("CREDT.RPT.ID", "DEL_GRTR_THIRTY_BALANCE_GRT_THREE_THOUSAND")
return(act)
}
DPDGRTR30_CURRBAL_GRTR3000<-pcblgtthreethousand(d)

PAYDEL_12MNT<-function(d)
{
bad<-function(d)
{
l<-function(d,c1,c2)
{
count<-ifelse(c1>30&(c1>c2),1,0)
return(count)
}
c1<-l(d,d$DPD...HIST_01,d$DPD...HIST_02)
c2<-l(d,d$DPD...HIST_02,d$DPD...HIST_03)
c3<-l(d,d$DPD...HIST_03,d$DPD...HIST_04)
c4<-l(d,d$DPD...HIST_04,d$DPD...HIST_05)
c5<-l(d,d$DPD...HIST_05,d$DPD...HIST_06)
c6<-l(d,d$DPD...HIST_06,d$DPD...HIST_07)
c7<-l(d,d$DPD...HIST_07,d$DPD...HIST_08)
c8<-l(d,d$DPD...HIST_08,d$DPD...HIST_09)
c9<-l(d,d$DPD...HIST_09,d$DPD...HIST_10)
c10<-l(d,d$DPD...HIST_10,d$DPD...HIST_11)
c11<-l(d,d$DPD...HIST_11,d$DPD...HIST_12)
c12<-l(d,d$DPD...HIST_12,d$DPD...HIST_13)
c1[is.na(c1)]<-0
c2[is.na(c2)]<-0
c3[is.na(c3)]<-0
c4[is.na(c4)]<-0
c5[is.na(c5)]<-0
c6[is.na(c6)]<-0
c7[is.na(c7)]<-0
c8[is.na(c8)]<-0
c9[is.na(c9)]<-0
c10[is.na(c10)]<-0
c11[is.na(c11)]<-0
c12[is.na(c12)]<-0


q<-c1+c2+c3+c4+c5+c6+c7+c8+c9+c10+c11+c12
return(q)

}
d$bb<-bad(d)
act<-aggregate(d$bb,list(crd=d$CREDT.RPT.ID),sum)
colnames(act) <- c("CREDT.RPT.ID", "DEL_INC_12_MNTH")
return(act)
}
INCREASE_12MNTH_DEL<-PAYDEL_12MNT(d)

# Merge resutls of all fucntions by credit report id
aggregate<-Reduce(function(x, y) merge(x, y, all=TRUE),list(ALL_TRADES,PDT_TYPE,DPDGRTR30_CURRBAL_GRTR3000,INCREASE_12MNTH_DEL))

#aggregate<-Reduce(function(x, y) merge(x, y,by=c("CREDT.RPT.ID"), all=TRUE), list(df1,aggregate))

return(aggregate)
# end of execution
print(Sys.time())
}

# Retro PR Date
date<-unique(df$RETRO.PR.DT)
date<-as.Date(paste(substr(date,1,2),'-',substr(date,4,5),'-',substr(date,7,10), sep = ''),  format="%d-%m-%Y")
df2$INQUIRY.DATE<-as.Date(df2$INQUIRY.DATE,"%d-%m-%Y")

counter = 1
row_counter = 0
print("data reading over")

##this loop splits data into smaller pieces. so we can read bigger files without needing excessive amount of RAM.
##it reads only 100k rows at once. by using arguments skip and nrow of read.csv function.
while(counter <= ceiling(rownumber/100000)){
  print(counter)
  for(i in 1:length(list.files())){
    if(tools::file_ext(list.files()[i])== "csv"){
      file <- read.csv(list.files()[i], sep="|",header=T,colClasses=c("CANDIDATE...ID"="character","LOS.APP.ID"="character"), nrows = 1)
      if((ncol(file) == 42 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
         (ncol(file) == 41 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
         (ncol(file) == 43 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") |
         (ncol(file) == 40 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID")){
        
        d <- read.csv(list.files()[i], sep="|",header=T,colClasses=c("CANDIDATE...ID"="character","LOS.APP.ID"="character"), skip = 1 + row_counter, nrows = 100000)
        rm(file)
        break
      } else if (i == length(list.files())){
        print("No Account file found!!")
      }
    }
  }
	colnames(d) <- column.names
	d<-d[nchar(as.character(d$REPORTED.DATE...HIST))>0,]
	d$X<-NULL




	# Data Preparation
	##deleted written strings from DAS...HIST columns
	d$DAS...HIST<-gsub("(.{3})", "\\1 ", d$DAS...HIST)
	d$DPD...HIST<-gsub("(.{3})", "\\1 ", d$DPD...HIST)
	d$ASSET.CLASS...HIST<-gsub("(.{3})", "\\1 ", d$ASSET.CLASS...HIST)
	d<-concat.split.multiple(d, split.col="ASSET.CLASS...HIST", sep=" ")
	d<-concat.split.multiple(d, split.col="DAS...HIST", sep=" ")

	d$DPD_HIST_ORIGINAL<-d$DPD...HIST
	## splits specified columns rergarding space seperators 
	d<-concat.split.multiple(d, split.col="DPD...HIST", sep=" ")

	d<-concat.split.multiple(d, split.col="CUR.BAL...HIST", sep=",")  
	d<-as.data.frame(d)
	dpd<-c("DPD...HIST_01","DPD...HIST_02","DPD...HIST_03","DPD...HIST_04","DPD...HIST_05","DPD...HIST_06","DPD...HIST_07","DPD...HIST_08","DPD...HIST_09","DPD...HIST_10","DPD...HIST_11","DPD...HIST_12","DPD...HIST_13","DPD...HIST_14","DPD...HIST_15","DPD...HIST_16","DPD...HIST_17","DPD...HIST_18","DPD...HIST_19","DPD...HIST_20","DPD...HIST_21","DPD...HIST_22","DPD...HIST_23","DPD...HIST_24","DPD...HIST_25","DPD...HIST_26","DPD...HIST_27","DPD...HIST_28","DPD...HIST_29","DPD...HIST_30","DPD...HIST_31","DPD...HIST_32","DPD...HIST_33","DPD...HIST_34","DPD...HIST_35","DPD...HIST_36")


	vars5<-names(d)%in%dpd

	acl<-c("ASSET.CLASS...HIST_01","ASSET.CLASS...HIST_02","ASSET.CLASS...HIST_03","ASSET.CLASS...HIST_04","ASSET.CLASS...HIST_05","ASSET.CLASS...HIST_06","ASSET.CLASS...HIST_07","ASSET.CLASS...HIST_08","ASSET.CLASS...HIST_09","ASSET.CLASS...HIST_10","ASSET.CLASS...HIST_11","ASSET.CLASS...HIST_12","ASSET.CLASS...HIST_13","ASSET.CLASS...HIST_14","ASSET.CLASS...HIST_15","ASSET.CLASS...HIST_16","ASSET.CLASS...HIST_17","ASSET.CLASS...HIST_18","ASSET.CLASS...HIST_19","ASSET.CLASS...HIST_20","ASSET.CLASS...HIST_21","ASSET.CLASS...HIST_22","ASSET.CLASS...HIST_23","ASSET.CLASS...HIST_24","ASSET.CLASS...HIST_25","ASSET.CLASS...HIST_26","ASSET.CLASS...HIST_27","ASSET.CLASS...HIST_28","ASSET.CLASS...HIST_29","ASSET.CLASS...HIST_30","ASSET.CLASS...HIST_31","ASSET.CLASS...HIST_32","ASSET.CLASS...HIST_33","ASSET.CLASS...HIST_34","ASSET.CLASS...HIST_35","ASSET.CLASS...HIST_36")

	vars6<-names(d)%in%acl
  ##sets differect values if some columns have the values shown below
	d[,vars6]<-apply(d[,vars6],2,FUN=as.character)
	d[,vars5]<-apply(d[,vars5],2,FUN=as.character)

	d[,vars6][d[,vars6]=="DDD"]<-0
	d[,vars6][d[,vars6]=="L05"]<-1
	d[,vars6][d[,vars6]=="L02"]<-91
	d[,vars6][d[,vars6]=="L01"]<-0
	d[,vars6][d[,vars6]=="L03"]<-361
	d[,vars6][d[,vars6]=="L04"]<-361
	d[,vars6][d[,vars6]=="XXX"]<-0
	d[,vars6]<-apply(d[,vars6],2,FUN=as.numeric)
	d[,vars5]<-apply(d[,vars5],2,FUN=as.numeric)

  ##changes the values if some of the columns show NA
	d$DPD...HIST_01<-ifelse(!is.na(d$DPD...HIST_01),d$DPD...HIST_01,d$ASSET.CLASS...HIST_01)
	d$DPD...HIST_02<-ifelse(!is.na(d$DPD...HIST_02),d$DPD...HIST_02,d$ASSET.CLASS...HIST_02)
	d$DPD...HIST_03<-ifelse(!is.na(d$DPD...HIST_03),d$DPD...HIST_03,d$ASSET.CLASS...HIST_03)
	d$DPD...HIST_04<-ifelse(!is.na(d$DPD...HIST_04),d$DPD...HIST_04,d$ASSET.CLASS...HIST_04)
	d$DPD...HIST_05<-ifelse(!is.na(d$DPD...HIST_05),d$DPD...HIST_05,d$ASSET.CLASS...HIST_05)
	d$DPD...HIST_06<-ifelse(!is.na(d$DPD...HIST_06),d$DPD...HIST_06,d$ASSET.CLASS...HIST_06)
	d$DPD...HIST_07<-ifelse(!is.na(d$DPD...HIST_07),d$DPD...HIST_07,d$ASSET.CLASS...HIST_07)
	d$DPD...HIST_08<-ifelse(!is.na(d$DPD...HIST_08),d$DPD...HIST_08,d$ASSET.CLASS...HIST_08)
	d$DPD...HIST_09<-ifelse(!is.na(d$DPD...HIST_09),d$DPD...HIST_09,d$ASSET.CLASS...HIST_09)
	d$DPD...HIST_10<-ifelse(!is.na(d$DPD...HIST_10),d$DPD...HIST_10,d$ASSET.CLASS...HIST_10)
	d$DPD...HIST_11<-ifelse(!is.na(d$DPD...HIST_11),d$DPD...HIST_11,d$ASSET.CLASS...HIST_11)
	d$DPD...HIST_12<-ifelse(!is.na(d$DPD...HIST_12),d$DPD...HIST_12,d$ASSET.CLASS...HIST_12)
	d$DPD...HIST_13<-ifelse(!is.na(d$DPD...HIST_13),d$DPD...HIST_13,d$ASSET.CLASS...HIST_13)


	aggregate <- k(d)
	aggregate<-as.data.frame(aggregate)

	#aggregate<- merge(aggregate,df3,by="CREDT.RPT.ID")

	#aggregate<-Reduce(function(x, y) merge(x, y,by=c("CREDT.RPT.ID"), all=TRUE), list(aggregate,df3,df4))

	#names(aggregate)[1:22] <- c("CREDT-RPT-ID","STATUS","ERROR","CRIF HM Score","DESCRIPTION","PRI-NO-OF-ACCTS","PRI-ACTIVE-ACCTS","PRI-OVERDUE-ACCTS","PRI-CURRENT-BALANCE","PRI-SANCTIONED-AMOUNT","PRI-DISBURSED-AMOUNT","SEC-NO-OF-ACCTS","SEC-ACTIVE-ACCTS","SEC-OVERDUE-ACCTS","SEC-CURRENT-BALANCE","SEC-SANCTIONED-AMOUNT","SEC-DISBURSED-AMOUNT","NEW-ACCTS-IN-LAST-SIX-MONTHS","DELINQUENT-ACCTS-IN-LAST-SIX-MONTHS","AVERAGE-ACCT-AGE","CREDIT-HISTORY-LENGTH","NO-OF_INQUIRIES")

	# write output data frame to flat file
	if (!file.exists("Setting")){
    dir.create("Setting")
  }
  setwd(".//Setting")
  
  #write a file with counter name
  write.table(aggregate,paste(counter,".csv", sep = ""),sep="|",row.names = FALSE)
  
  setwd("..")


	counter = counter + 1
	  
	row_counter = row_counter + 100000
	  

}

setwd(".//Setting")

final <- matrix(data = NA, nrow = 1, ncol = 47)
colnames(final) = c('CREDT.RPT.ID','ALL_TYPES_TRADES.Active','ALL_TYPES_TRADES.Closed','ALL_TYPES_TRADES.Delinquent','ALL_TYPES_TRADES.Restructured',
'ALL_TYPES_TRADES.Settled','ALL_TYPES_TRADES.Suit Filed','ALL_TYPES_TRADES.Written Off','TRADES.Auto Loan (Personal)','TRADES.Business Loan Against Bank Deposits',
'TRADES.Business Loan General','TRADES.Business Loan Priority Sector  Agriculture','TRADES.Business Loan Priority Sector  Others',
'TRADES.Business Loan Priority Sector  Small Business','TRADES.Business Non-Funded Credit Facility-Priority Sector- Small Business',
'TRADES.Business Non-Funded Credit Facility General','TRADES.Commercial Vehicle Loan','TRADES.Construction Equipment Loan','TRADES.Consumer Loan',
'TRADES.Corporate Credit Card','TRADES.Credit Card','TRADES.Education Loan','TRADES.Fleet Card','TRADES.Gold Loan','TRADES.Housing Loan','TRADES.Individual',
'TRADES.JLG Individual','TRADES.Kisan Credit Card','TRADES.Leasing','TRADES.Loan Against Bank Deposits','TRADES.Loan against Card','TRADES.Loan Against Shares / Securities',
'TRADES.Loan to Professional','TRADES.Microfinance Business Loan','TRADES.Microfinance Personal Loan','TRADES.Non-Funded Credit Facility','TRADES.Other',
'TRADES.Overdraft','TRADES.Personal Loan','TRADES.Property Loan','TRADES.Secured Credit Card','TRADES.Staff Loan','TRADES.Two-Wheeler Loan','TRADES.Used Car Loan',
'TRADES.Used Tractor Loan','DEL_GRTR_THIRTY_BALANCE_GRT_THREE_THOUSAND','DEL_INC_12_MNTH')
final <- as.data.frame(final)
for(file in 1:length(list.files())){
  newfile <- read.csv(list.files()[file], sep = "|", header = T)
  
  final <- plyr::rbind.fill(final, newfile)
}

## deletes the auxiallary folder.
setwd("..")
unlink("Setting")

# sets the wd to output location we defined and save with the chosen name.
setwd(output_loc)
final <- unique(final)
final <- final[-1,]
write.table(final,file = output_name,sep="|",row.names = FALSE)
print(Sys.time())
gc()
rm(list=ls(all=TRUE))


