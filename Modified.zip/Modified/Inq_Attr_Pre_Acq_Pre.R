# State of Execution
print(Sys.time())
memory.limit(8000)

#Load Libraries

library(data.table)
library(dplyr)
library(stringr)
library(splitstackshape)
library(tcltk)
library(rstudioapi)
library(Rserve)
library(plyr)
Rserve()

get_scriptpath <- function() {
  # location of script can depend on how it was invoked:
  # source() and knit() put it in sys.calls()
  path <- NULL
  
  if(!is.null(sys.calls())) {
    
    path <- as.character(sys.call(1))[2] 
    # make sure we got a file that ends in .R, .Rmd or .Rnw
    if (grepl("..+\\.[R|Rmd|Rnw]", path, perl=TRUE, ignore.case = TRUE) )  {
      return(path)
    } else { 
      message("Obtained value for path does not end with .R, .Rmd or .Rnw: ", path)
    }
  } else{
    # Rscript and R -f put it in commandArgs
    args <- commandArgs(trailingOnly = FALSE)
  }
  return(path)
}


mypath <- get_scriptpath()

DIR <- dirname(mypath)
setwd(DIR)
setwd("..")
setwd(".//download")


output_loc <- tk_choose.dir(getwd(),"Please choose the location to save the output files.")

varEntryDialog <- function(vars,
                           labels = vars,
                           fun = rep(list(as.character), length(vars)),
                           title = 'Variable Entry',
                           prompt = NULL) {
  require(tcltk)
  stopifnot(length(vars) == length(labels), length(labels) == length(fun))
  # Create a variable to keep track of the state of the dialog window:
  # done = 0; If the window is active
  # done = 1; If the window has been closed using the OK button
  # done = 2; If the window has been closed using the Cancel button or destroyed
  done <- tclVar(0)
  tt <- tktoplevel()
  tkwm.title(tt, title)
  entries <- list()
  tclvars <- list()
  # Capture the event "Destroy" (e.g. Alt-F4 in Windows) and when this happens,
  # assign 2 to done.
  tkbind(tt,"<Destroy>",function() tclvalue(done)<-2)
  for(i in seq_along(vars)) {
    tclvars[[i]] <- tclVar("Inquiry_PRE.csv")
    entries[[i]] <- tkentry(tt, textvariable=tclvars[[i]])
  }
  doneVal <- as.integer(tclvalue(done))
  results <- list()
  reset <- function() {
    for(i in seq_along(entries)) {
      tclvalue(tclvars[[i]]) <<- ""
    }
  }
  reset.but <- tkbutton(tt, text="Reset", command=reset)
  cancel <- function() {
    tclvalue(done) <- 2
  }
  cancel.but <- tkbutton(tt, text='Cancel', command=cancel)
  submit <- function() {
    for(i in seq_along(vars)) {
      tryCatch( {
        results[[vars[[i]]]] <<- fun[[i]](tclvalue(tclvars[[i]]))
        tclvalue(done) <- 1
      },
      error = function(e) { tkmessageBox(message=geterrmessage()) },
      finally = { }
      )
    }
  }
  submit.but <- tkbutton(tt, text="Submit", command=submit)
  if(!is.null(prompt)) {
    tkgrid(tklabel(tt,text=prompt), columnspan=3, pady=5)
  }
  for(i in seq_along(vars)) {
    tkgrid(tklabel(tt, text=labels[i]), entries[[i]], pady=10, padx=10, columnspan=4)
  }
  tkgrid(submit.but, cancel.but, reset.but, pady=10, padx=10, columnspan=3)
  tkfocus(tt)
  # Do not proceed with the following code until the variable done is non-zero.
  # (But other processes can still run, i.e. the system is not frozen.)
  tkwait.variable(done)
  if(tclvalue(done) != 1) {
    results <- NULL
  }
  tkdestroy(tt)
  return(results)
}

var1 <- varEntryDialog(vars = 'Name', title = 'Output file name', prompt = 'Input name of the output file:')

output_name <- var1$Name

#Input Data
#dff<-read.table("D:/Script/Pre_Acq/Account_Pre_Acq.csv",sep="|",header=T,stringsAsFactors=FALSE,colClasses=c("LOS.APP.ID"="character"))

for(i in 1:length(list.files())){
  if(tools::file_ext(list.files()[i])== "csv"){
  file <- read.csv(list.files()[i], sep="|",header=T,stringsAsFactors=FALSE,colClasses=c("LOS.APP.ID"="character"), nrows = 1)
  if((ncol(file) == 42 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
     (ncol(file) == 41 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
     (ncol(file) == 43 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") |
     (ncol(file) == 40 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID")){
    
    dff <- read.csv(list.files()[i], sep="|",header=T,stringsAsFactors=FALSE,colClasses=c("LOS.APP.ID"="character"))
    rm(file)
    break
  } else if (i == length(list.files())){
    print("No Account file found!!")
  }
  }
}


for(i in 1:length(list.files())){
  if(tools::file_ext(list.files()[i])== "csv"){
    file <- read.csv(list.files()[i],sep="|",header=T,stringsAsFactors=FALSE,colClasses=c("LOS.APP.ID"="character"), nrows = 1)
    if((ncol(file) == 28 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")|
       (ncol(file) == 27 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")|
       (ncol(file) == 26 & colnames(file)[2] == "CUSTOMER.ID.MBR.ID" & colnames(file)[3] == "LOS.APP.ID")){
      
      df1 <- read.csv(list.files()[i],sep="|",header=T,stringsAsFactors=FALSE,colClasses=c("LOS.APP.ID"="character"))
      rm(file)
      break
    } else if (i == length(list.files())){
      print("No Summary file found!!")
    }
  }
}
df1$X<-NULL


rownumber <- nrow(dff)
column.names <- colnames(dff)

rm(dff)
gc()
counter = 1
row_counter = 0


while(counter <= ceiling(rownumber/100000)){
  for(i in 1:length(list.files())){
    if(tools::file_ext(list.files()[i])== "csv"){
      file <- read.csv(list.files()[i], sep="|",header=T,stringsAsFactors=FALSE,colClasses=c("LOS.APP.ID"="character"), nrows = 1)
      if((ncol(file) == 42 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
         (ncol(file) == 41 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
         (ncol(file) == 43 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") |
         (ncol(file) == 40 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID")){
        
        dff <- read.csv(list.files()[i], sep="|",header=F,stringsAsFactors=FALSE,colClasses=c("LOS.APP.ID"="character"), nrow = 100000, skip = 1+row_counter)
        rm(file)
        break
      } else if (i == length(list.files())){
        print("No Account file found!!")
      }
    }
  } 
  
  colnames(dff) <- column.names
  
  
  dff<-dff[dff$ACCT.TYPE=="Housing Loan"|dff$ACCT.TYPE=="Auto Loan (Personal)"|dff$ACCT.TYPE=="Two-Wheeler Loan"|dff$ACCT.TYPE=="Property Loan"|dff$ACCT.TYPE=="Credit Card"|dff$ACCT.TYPE=="Personal Loan"|dff$ACCT.TYPE=="Consumer Loan" & length(dff$REPORTED.DATE...HIST)>0,]
  dff<-subset(dff,select=c(CREDT.RPT.ID,LOS.APP.ID,ACCT.TYPE,ACCOUNT.STATUS,HIGH.CRD...HIST,CUR.BAL...HIST,AMT.PAID...HIST,REPORTED.DATE...HIST))
  
  d <- mutate(dff, key1 = rownames(dff))
  d$key<-paste(d$CREDT.RPT.ID,d$key1,sep="-")
  
  d<-concat.split.multiple(d, split.col="HIGH.CRD...HIST", sep=",",drop=FALSE)
  d<-concat.split.multiple(d, split.col="CUR.BAL...HIST", sep=",",drop=FALSE)
  d<-concat.split.multiple(d, split.col="AMT.PAID...HIST", sep=",",drop=FALSE)
  
  d<-subset(d,select=c(key,CREDT.RPT.ID:ACCOUNT.STATUS,HIGH.CRD...HIST_01:HIGH.CRD...HIST_13,CUR.BAL...HIST_01:CUR.BAL...HIST_13,AMT.PAID...HIST_01:AMT.PAID...HIST_13))
  
  d$utilization_1<-ifelse(!is.na(d$HIGH.CRD...HIST_01) ,as.numeric(d$CUR.BAL...HIST_01)/as.numeric(d$HIGH.CRD...HIST_01),NA) 
  d$utilization_2<-ifelse(!is.na(d$HIGH.CRD...HIST_02) ,as.numeric(d$CUR.BAL...HIST_02)/as.numeric(d$HIGH.CRD...HIST_02),NA) 
  d$utilization_3<-ifelse(!is.na(d$HIGH.CRD...HIST_03) ,as.numeric(d$CUR.BAL...HIST_03)/as.numeric(d$HIGH.CRD...HIST_03),NA) 
  d$utilization_4<-ifelse(!is.na(d$HIGH.CRD...HIST_04) ,as.numeric(d$CUR.BAL...HIST_04)/as.numeric(d$HIGH.CRD...HIST_04),NA) 
  d$utilization_5<-ifelse(!is.na(d$HIGH.CRD...HIST_05) ,as.numeric(d$CUR.BAL...HIST_05)/as.numeric(d$HIGH.CRD...HIST_05),NA) 
  d$utilization_6<-ifelse(!is.na(d$HIGH.CRD...HIST_06) ,as.numeric(d$CUR.BAL...HIST_06)/as.numeric(d$HIGH.CRD...HIST_06),NA) 
  d$utilization_7<-ifelse(!is.na(d$HIGH.CRD...HIST_07) ,as.numeric(d$CUR.BAL...HIST_07)/as.numeric(d$HIGH.CRD...HIST_07),NA) 
  d$utilization_8<-ifelse(!is.na(d$HIGH.CRD...HIST_08) ,as.numeric(d$CUR.BAL...HIST_08)/as.numeric(d$HIGH.CRD...HIST_08),NA) 
  d$utilization_9<-ifelse(!is.na(d$HIGH.CRD...HIST_09) ,as.numeric(d$CUR.BAL...HIST_09)/as.numeric(d$HIGH.CRD...HIST_09),NA) 
  d$utilization_10<-ifelse(!is.na(d$HIGH.CRD...HIST_10) ,as.numeric(d$CUR.BAL...HIST_10)/as.numeric(d$HIGH.CRD...HIST_10),NA)
  d$utilization_11<-ifelse(!is.na(d$HIGH.CRD...HIST_11) ,as.numeric(d$CUR.BAL...HIST_11)/as.numeric(d$HIGH.CRD...HIST_11),NA) 
  d$utilization_12<-ifelse(!is.na(d$HIGH.CRD...HIST_12) ,as.numeric(d$CUR.BAL...HIST_12)/as.numeric(d$HIGH.CRD...HIST_12),NA) 
  
  d$CC_Util_70_Per_12_Months<-ifelse(d$utilization_1>=0.7,1,0)+ifelse(d$utilization_2>=0.7,1,0)+ifelse(d$utilization_3>=0.7,1,0)+ifelse(d$utilization_4>=0.7,1,0)+ifelse(d$utilization_5>=0.7,1,0)+ifelse(d$utilization_6>=0.7,1,0)+ifelse(d$utilization_7>=0.7,1,0)+ifelse(d$utilization_8>=0.7,1,0)+ifelse(d$utilization_9>=0.7,1,0)+ifelse(d$utilization_10>=0.7,1,0)+ifelse(d$utilization_11>=0.7,1,0)+ifelse(d$utilization_12>=0.7,1,0)
  d$CC_Util_70_Per_6_Months<-ifelse(d$utilization_1>=0.7,1,0)+ifelse(d$utilization_2>=0.7,1,0)+ifelse(d$utilization_3>=0.7,1,0)+ifelse(d$utilization_4>=0.7,1,0)+ifelse(d$utilization_5>=0.7,1,0)+ifelse(d$utilization_6>=0.7,1,0)
  
  #d$current_balance_array<-paste(CUR.BAL...HIST_01,",",CUR.BAL...HIST_02,",",CUR.BAL...HIST_03,",",CUR.BAL...HIST_04,",",CUR.BAL...HIST_05,",",CUR.BAL...HIST_06,",",CUR.BAL...HIST_07,",",CUR.BAL...HIST_08,",",CUR.BAL...HIST_09,",",CUR.BAL...HIST_10,",",CUR.BAL...HIST_11,",",CUR.BAL...HIST_12)
  
  d$PAY_RATIO_6M_NUM<-(as.numeric(d$AMT.PAID...HIST_01)+as.numeric(d$AMT.PAID...HIST_02)+as.numeric(d$AMT.PAID...HIST_03)+as.numeric(d$AMT.PAID...HIST_04)+as.numeric(d$AMT.PAID...HIST_05)+as.numeric(d$AMT.PAID...HIST_06))
  d$PAY_RATIO_6M_DEN<-(as.numeric(d$CUR.BAL...HIST_02)+as.numeric(d$CUR.BAL...HIST_03)+as.numeric(d$CUR.BAL...HIST_04)+as.numeric(d$CUR.BAL...HIST_05)+as.numeric(d$CUR.BAL...HIST_06)+as.numeric(d$CUR.BAL...HIST_07))
  
  d<-as.data.frame(d)
  
  k<-function(d)
  {
    
    PAY_RATIO_CC_6_MONTHS<-function(d)
    {
      d<-d[d$ACCT.TYPE=="Credit Card",]
      act_num<-aggregate(d$PAY_RATIO_6M_NUM,list(crd=d$CREDT.RPT.ID),sum,na.rm=TRUE)
      colnames(act_num) <- c("CREDT.RPT.ID", "PAY_RATIO_CC_6_MONTHS_NUM")
      act_den<-aggregate(d$PAY_RATIO_6M_DEN,list(crd=d$CREDT.RPT.ID),sum,na.rm=TRUE)
      colnames(act_den) <- c("CREDT.RPT.ID", "PAY_RATIO_CC_6_MONTHS_DEN")
      act<-Reduce(function(x, y) merge(x, y,by=c("CREDT.RPT.ID"), all=TRUE), list(act_num,act_den))
      act<-mutate(act, PAY_RATIO_CC_6_MONTHS = PAY_RATIO_CC_6_MONTHS_NUM / PAY_RATIO_CC_6_MONTHS_DEN)
      return(act)
    }
    PAY_RATIO_CC_6_MONTHS<-PAY_RATIO_CC_6_MONTHS(d)
    
    AVG_AMT_PAID_6_MONTHS_SECURED<-function(d)
    {
      d<-d[d$ACCT.TYPE=="Housing Loan"|d$ACCT.TYPE=="Auto Loan (Personal)"|d$ACCT.TYPE=="Two-Wheeler Loan"|d$ACCT.TYPE=="Property Loan",]
      act<-aggregate(d$PAY_RATIO_6M_NUM,list(crd=d$CREDT.RPT.ID),sum,na.rm=TRUE)
      colnames(act) <- c("CREDT.RPT.ID", "AMT_PAID_6_MONTHS_SECURED")
      act<-mutate(act, AVG_AMT_PAID_6_MONTHS_SECURED = AMT_PAID_6_MONTHS_SECURED/6) 
      return(act)
    }
    AVG_AMT_PAID_6_MONTHS_SECURED<-AVG_AMT_PAID_6_MONTHS_SECURED(d)
    
    AVG_AMT_PAID_6_MONTHS_UNSECURED<-function(d)
    {
      d<-d[d$ACCT.TYPE=="Credit Card"|d$ACCT.TYPE=="Personal Loan"|d$ACCT.TYPE=="Consumer Loan",]
      act<-aggregate(d$PAY_RATIO_6M_NUM,list(crd=d$CREDT.RPT.ID),sum,na.rm=TRUE)
      colnames(act) <- c("CREDT.RPT.ID", "AMT_PAID_6_MONTHS_UNSECURED")
      act<-mutate(act, AVG_AMT_PAID_6_MONTHS_UNSECURED = AMT_PAID_6_MONTHS_UNSECURED/6) 
      return(act)
    }
    AVG_AMT_PAID_6_MONTHS_UNSECURED<-AVG_AMT_PAID_6_MONTHS_UNSECURED(d)
    
    CC_UTIL_70PER_12M<-function(d)
    {
      d<-d[(d$ACCOUNT.STATUS=="Active"|d$ACCOUNT.STATUS=="Delinquent") & d$ACCT.TYPE=="Credit Card",]
      act<-aggregate(d$CC_Util_70_Per_12_Months,list(crd=d$CREDT.RPT.ID),sum,na.rm=TRUE)
      colnames(act) <- c("CREDT.RPT.ID", "CC_UTIL_70PER_12M")
      return(act)
    }
    CC_UTIL_70PER_12M<-CC_UTIL_70PER_12M(d)
    
    CC_UTIL_70PER_6M<-function(d)
    {
      d<-d[(d$ACCOUNT.STATUS=="Active"|d$ACCOUNT.STATUS=="Delinquent") & d$ACCT.TYPE=="Credit Card",]
      act<-aggregate(d$CC_Util_70_Per_6_Months,list(crd=d$CREDT.RPT.ID),sum,na.rm=TRUE)
      colnames(act) <- c("CREDT.RPT.ID", "CC_UTIL_70PER_6M")
      return(act)
    }
    CC_UTIL_70PER_6M<-CC_UTIL_70PER_6M(d)
    
    MAX_CC_UTIL_12_MONTHS<-function(d)
    {
      d<-d[(d$ACCOUNT.STATUS=="Active"|d$ACCOUNT.STATUS=="Delinquent") & d$ACCT.TYPE=="Credit Card",]
      d<-subset(d,select=c(CREDT.RPT.ID,utilization_1:utilization_12))
      d$max_util<-apply(d[,2:13],1,max, na.rm=FALSE)
      act<-aggregate(d$max_util,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
      colnames(act) <- c("CREDT.RPT.ID", "MAX_CC_UTIL_12_MONTHS")
      return(act)
    }
    MAX_CC_UTIL_12_MONTHS<-MAX_CC_UTIL_12_MONTHS(d)
    
    MAX_CC_UTIL_6_MONTHS<-function(d)
    {
      d<-d[(d$ACCOUNT.STATUS=="Active"|d$ACCOUNT.STATUS=="Delinquent") & d$ACCT.TYPE=="Credit Card",]
      d<-subset(d,select=c(CREDT.RPT.ID,utilization_1:utilization_6))
      d$max_util<-apply(d[,2:7],1,max, na.rm=FALSE)
      act<-aggregate(d$max_util,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
      colnames(act) <- c("CREDT.RPT.ID", "MAX_CC_UTIL_6_MONTHS")
      return(act)
    }
    MAX_CC_UTIL_6_MONTHS<-MAX_CC_UTIL_6_MONTHS(d)
    
    SEC_AMT_PAID_6M_INCREASE<-function(d)
    {
      d<-d[d$ACCT.TYPE=="Housing Loan"|d$ACCT.TYPE=="Auto Loan (Personal)"|d$ACCT.TYPE=="Two-Wheeler Loan"|d$ACCT.TYPE=="Property Loan",]
      bad<-function(d)
      {
        aggregate_amount_paid<-function(d)
        {
          amount_paid_1<-aggregate(d$AMT.PAID...HIST_01,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_1) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_01")
          amount_paid_2<-aggregate(d$AMT.PAID...HIST_02,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_2) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_02")
          amount_paid_3<-aggregate(d$AMT.PAID...HIST_03,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_3) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_03")
          amount_paid_4<-aggregate(d$AMT.PAID...HIST_04,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_4) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_04")
          amount_paid_5<-aggregate(d$AMT.PAID...HIST_05,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_5) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_05")
          amount_paid_6<-aggregate(d$AMT.PAID...HIST_06,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_6) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_06")
          temp<-Reduce(function(x, y) merge(x, y,by=c("CREDT.RPT.ID"), all=TRUE), list(amount_paid_1,amount_paid_2,amount_paid_3,amount_paid_4,amount_paid_5,amount_paid_6))
          temp<-as.data.frame(temp)
          return(temp)
        }
        aggregate_amount_paid<-aggregate_amount_paid(d)
        
        l<-function(aggregate_amount_paid,c1,c2)
        {
          count<-ifelse(c1>c2,1,0)
          return(count)
        }
        c1<-l(aggregate_amount_paid,d$AMT.PAID...HIST_01,d$AMT.PAID...HIST_02)
        c2<-l(aggregate_amount_paid,d$AMT.PAID...HIST_02,d$AMT.PAID...HIST_03)
        c3<-l(aggregate_amount_paid,d$AMT.PAID...HIST_03,d$AMT.PAID...HIST_04)
        c4<-l(aggregate_amount_paid,d$AMT.PAID...HIST_04,d$AMT.PAID...HIST_05)
        c5<-l(aggregate_amount_paid,d$AMT.PAID...HIST_05,d$AMT.PAID...HIST_06)
        c6<-l(aggregate_amount_paid,d$AMT.PAID...HIST_06,d$AMT.PAID...HIST_07)
        
        c1[is.na(c1)]<-0
        c2[is.na(c2)]<-0
        c3[is.na(c3)]<-0
        c4[is.na(c4)]<-0
        c5[is.na(c5)]<-0
        c6[is.na(c6)]<-0
        
        q<-c1+c2+c3+c4+c5+c6
        return(q)
      }
      d$bb<-bad(d)
      act<-aggregate(d$bb,list(crd=d$CREDT.RPT.ID),sum)
      colnames(act) <- c("CREDT.RPT.ID", "SEC_AMT_PAID_6M_INCREASE")
      return(act)
    }
    SEC_AMT_PAID_6M_INCREASE<-SEC_AMT_PAID_6M_INCREASE(d)
    
    UNSEC_AMT_PAID_6M_INCREASE<-function(d)
    {
      d<-d[d$ACCT.TYPE=="Credit Card"|d$ACCT.TYPE=="Personal Loan"|d$ACCT.TYPE=="Consumer Loan",]
      bad<-function(d)
      {
        aggregate_amount_paid<-function(d)
        {
          amount_paid_1<-aggregate(d$AMT.PAID...HIST_01,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_1) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_01")
          amount_paid_2<-aggregate(d$AMT.PAID...HIST_02,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_2) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_02")
          amount_paid_3<-aggregate(d$AMT.PAID...HIST_03,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_3) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_03")
          amount_paid_4<-aggregate(d$AMT.PAID...HIST_04,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_4) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_04")
          amount_paid_5<-aggregate(d$AMT.PAID...HIST_05,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_5) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_05")
          amount_paid_6<-aggregate(d$AMT.PAID...HIST_06,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_6) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_06")
          temp<-Reduce(function(x, y) merge(x, y,by=c("CREDT.RPT.ID"), all=TRUE), list(amount_paid_1,amount_paid_2,amount_paid_3,amount_paid_4,amount_paid_5,amount_paid_6))
          temp<-as.data.frame(temp)
          return(temp)
        }
        aggregate_amount_paid<-aggregate_amount_paid(d)
        
        l<-function(aggregate_amount_paid,c1,c2)
        {
          count<-ifelse(c1>c2,1,0)
          return(count)
        }
        c1<-l(aggregate_amount_paid,d$AMT.PAID...HIST_01,d$AMT.PAID...HIST_02)
        c2<-l(aggregate_amount_paid,d$AMT.PAID...HIST_02,d$AMT.PAID...HIST_03)
        c3<-l(aggregate_amount_paid,d$AMT.PAID...HIST_03,d$AMT.PAID...HIST_04)
        c4<-l(aggregate_amount_paid,d$AMT.PAID...HIST_04,d$AMT.PAID...HIST_05)
        c5<-l(aggregate_amount_paid,d$AMT.PAID...HIST_05,d$AMT.PAID...HIST_06)
        c6<-l(aggregate_amount_paid,d$AMT.PAID...HIST_06,d$AMT.PAID...HIST_07)
        
        c1[is.na(c1)]<-0
        c2[is.na(c2)]<-0
        c3[is.na(c3)]<-0
        c4[is.na(c4)]<-0
        c5[is.na(c5)]<-0
        c6[is.na(c6)]<-0
        
        q<-c1+c2+c3+c4+c5+c6
        return(q)
      }
      d$bb<-bad(d)
      act<-aggregate(d$bb,list(crd=d$CREDT.RPT.ID),sum)
      colnames(act) <- c("CREDT.RPT.ID", "UNSEC_AMT_PAID_6M_INCREASE")
      return(act)
    }
    UNSEC_AMT_PAID_6M_INCREASE<-UNSEC_AMT_PAID_6M_INCREASE(d)
    
    SEC_AMT_PAID_6M_DECREASE<-function(d)
    {
      d<-d[d$ACCT.TYPE=="Housing Loan"|d$ACCT.TYPE=="Auto Loan (Personal)"|d$ACCT.TYPE=="Two-Wheeler Loan"|d$ACCT.TYPE=="Property Loan",]
      bad<-function(d)
      {
        aggregate_amount_paid<-function(d)
        {
          amount_paid_1<-aggregate(d$AMT.PAID...HIST_01,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_1) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_01")
          amount_paid_2<-aggregate(d$AMT.PAID...HIST_02,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_2) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_02")
          amount_paid_3<-aggregate(d$AMT.PAID...HIST_03,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_3) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_03")
          amount_paid_4<-aggregate(d$AMT.PAID...HIST_04,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_4) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_04")
          amount_paid_5<-aggregate(d$AMT.PAID...HIST_05,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_5) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_05")
          amount_paid_6<-aggregate(d$AMT.PAID...HIST_06,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_6) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_06")
          temp<-Reduce(function(x, y) merge(x, y,by=c("CREDT.RPT.ID"), all=TRUE), list(amount_paid_1,amount_paid_2,amount_paid_3,amount_paid_4,amount_paid_5,amount_paid_6))
          temp<-as.data.frame(temp)
          return(temp)
        }
        aggregate_amount_paid<-aggregate_amount_paid(d)
        
        l<-function(aggregate_amount_paid,c1,c2)
        {
          count<-ifelse(c1<c2,1,0)
          return(count)
        }
        c1<-l(aggregate_amount_paid,d$AMT.PAID...HIST_01,d$AMT.PAID...HIST_02)
        c2<-l(aggregate_amount_paid,d$AMT.PAID...HIST_02,d$AMT.PAID...HIST_03)
        c3<-l(aggregate_amount_paid,d$AMT.PAID...HIST_03,d$AMT.PAID...HIST_04)
        c4<-l(aggregate_amount_paid,d$AMT.PAID...HIST_04,d$AMT.PAID...HIST_05)
        c5<-l(aggregate_amount_paid,d$AMT.PAID...HIST_05,d$AMT.PAID...HIST_06)
        c6<-l(aggregate_amount_paid,d$AMT.PAID...HIST_06,d$AMT.PAID...HIST_07)
        
        c1[is.na(c1)]<-0
        c2[is.na(c2)]<-0
        c3[is.na(c3)]<-0
        c4[is.na(c4)]<-0
        c5[is.na(c5)]<-0
        c6[is.na(c6)]<-0
        
        q<-c1+c2+c3+c4+c5+c6
        return(q)
      }
      d$bb<-bad(d)
      act<-aggregate(d$bb,list(crd=d$CREDT.RPT.ID),sum)
      colnames(act) <- c("CREDT.RPT.ID", "SEC_AMT_PAID_6M_DECREASE")
      return(act)
    }
    SEC_AMT_PAID_6M_DECREASE<-SEC_AMT_PAID_6M_DECREASE(d)
    
    UNSEC_AMT_PAID_6M_DECREASE<-function(d)
    {
      d<-d[d$ACCT.TYPE=="Credit Card"|d$ACCT.TYPE=="Personal Loan"|d$ACCT.TYPE=="Consumer Loan",]
      bad<-function(d)
      {
        aggregate_amount_paid<-function(d)
        {
          amount_paid_1<-aggregate(d$AMT.PAID...HIST_01,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_1) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_01")
          amount_paid_2<-aggregate(d$AMT.PAID...HIST_02,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_2) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_02")
          amount_paid_3<-aggregate(d$AMT.PAID...HIST_03,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_3) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_03")
          amount_paid_4<-aggregate(d$AMT.PAID...HIST_04,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_4) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_04")
          amount_paid_5<-aggregate(d$AMT.PAID...HIST_05,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_5) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_05")
          amount_paid_6<-aggregate(d$AMT.PAID...HIST_06,list(crd=d$CREDT.RPT.ID),max,na.rm=TRUE)
          colnames(amount_paid_6) <- c("CREDT.RPT.ID", "AMT.PAID...HIST_06")
          temp<-Reduce(function(x, y) merge(x, y,by=c("CREDT.RPT.ID"), all=TRUE), list(amount_paid_1,amount_paid_2,amount_paid_3,amount_paid_4,amount_paid_5,amount_paid_6))
          temp<-as.data.frame(temp)
          return(temp)
        }
        aggregate_amount_paid<-aggregate_amount_paid(d)
        
        l<-function(aggregate_amount_paid,c1,c2)
        {
          count<-ifelse(c1<c2,1,0)
          return(count)
        }
        c1<-l(aggregate_amount_paid,d$AMT.PAID...HIST_01,d$AMT.PAID...HIST_02)
        c2<-l(aggregate_amount_paid,d$AMT.PAID...HIST_02,d$AMT.PAID...HIST_03)
        c3<-l(aggregate_amount_paid,d$AMT.PAID...HIST_03,d$AMT.PAID...HIST_04)
        c4<-l(aggregate_amount_paid,d$AMT.PAID...HIST_04,d$AMT.PAID...HIST_05)
        c5<-l(aggregate_amount_paid,d$AMT.PAID...HIST_05,d$AMT.PAID...HIST_06)
        c6<-l(aggregate_amount_paid,d$AMT.PAID...HIST_06,d$AMT.PAID...HIST_07)
        
        c1[is.na(c1)]<-0
        c2[is.na(c2)]<-0
        c3[is.na(c3)]<-0
        c4[is.na(c4)]<-0
        c5[is.na(c5)]<-0
        c6[is.na(c6)]<-0
        
        q<-c1+c2+c3+c4+c5+c6
        return(q)
      }
      d$bb<-bad(d)
      act<-aggregate(d$bb,list(crd=d$CREDT.RPT.ID),sum)
      colnames(act) <- c("CREDT.RPT.ID", "UNSEC_AMT_PAID_6M_DECREASE")
      return(act)
    }
    UNSEC_AMT_PAID_6M_DECREASE<-UNSEC_AMT_PAID_6M_DECREASE(d)
    
    # Merge resutls of all fucntions by credit report id
    aggregate<-Reduce(function(x, y) merge(x, y,by=c("CREDT.RPT.ID"), all=TRUE),list(PAY_RATIO_CC_6_MONTHS,AVG_AMT_PAID_6_MONTHS_SECURED,AVG_AMT_PAID_6_MONTHS_UNSECURED,CC_UTIL_70PER_12M,CC_UTIL_70PER_6M,MAX_CC_UTIL_12_MONTHS,MAX_CC_UTIL_6_MONTHS,SEC_AMT_PAID_6M_INCREASE,UNSEC_AMT_PAID_6M_INCREASE,SEC_AMT_PAID_6M_DECREASE,UNSEC_AMT_PAID_6M_DECREASE))
    as.data.frame(aggregate)
    
    return(aggregate)
    # end of execution
  }
  
  aggregate <- k(d)
  
  aggregate<- merge(df1,aggregate,by="CREDT.RPT.ID")
  
  
  if (!file.exists("Setting")){
    dir.create("Setting")
  }
  
  setwd(".//Setting")
  
  
  write.table(aggregate,paste(counter,".csv", sep = ""),sep="|",row.names = FALSE)
  
  setwd("..")
  
  counter = counter + 1
  
  row_counter = row_counter + 100000
  
  
}

setwd(".//Setting")

final <- matrix(data = NA, nrow = 1, ncol = 41)
colnames(final) = c('CREDT.RPT.ID','CUSTOMER.ID.MBR.ID','LOS.APP.ID','STATUS','ERROR','PERFORM_CNS.SCORE',
                    'PERFORM_CNS.SCORE.DESCRIPTION','PRI.NO.OF.ACCTS','PRI.ACTIVE.ACCTS','PRI.OVERDUE.ACCTS',
                    'PRI.CURRENT.BALANCE','PRI.SANCTIONED.AMOUNT','PRI.DISBURSED.AMOUNT','SEC.NO.OF.ACCTS',
                    'SEC.ACTIVE.ACCTS','SEC.OVERDUE.ACCTS','SEC.CURRENT.BALANCE','SEC.SANCTIONED.AMOUNT',
                    'SEC.DISBURSED.AMOUNT','PRIMARY.INSTAL.AMT','SEC.INSTAL.AMT','NEW.ACCTS.IN.LAST.SIX.MONTHS',
                    'DELINQUENT.ACCTS.IN.LAST.SIX.MONTHS','AVERAGE.ACCT.AGE','CREDIT.HISTORY.LENGTH',
                    'NO.OF_INQUIRIES','PAY_RATIO_CC_6_MONTHS_NUM','PAY_RATIO_CC_6_MONTHS_DEN','PAY_RATIO_CC_6_MONTHS',
                    'AMT_PAID_6_MONTHS_SECURED','AVG_AMT_PAID_6_MONTHS_SECURED','AMT_PAID_6_MONTHS_UNSECURED',
                    'AVG_AMT_PAID_6_MONTHS_UNSECURED','CC_UTIL_70PER_12M','CC_UTIL_70PER_6M','MAX_CC_UTIL_12_MONTHS',
                    'MAX_CC_UTIL_6_MONTHS','SEC_AMT_PAID_6M_INCREASE','UNSEC_AMT_PAID_6M_INCREASE',
                    'SEC_AMT_PAID_6M_DECREASE','UNSEC_AMT_PAID_6M_DECREASE')
final <- as.data.frame(final)
for(file in 1:length(list.files())){
  newfile <- read.csv(list.files()[file], sep = "|", header = T)
  
  final <- plyr::rbind.fill(final, newfile)
}
setwd("..")

unlink("Setting")
# go to orginal project folder

setwd(output_loc)


final <- unique(final)
final <- final[-1,]
write.table(final,file = output_name,sep="|",row.names = FALSE)
print(Sys.time())

gc()
rm(list=ls(all=TRUE))




