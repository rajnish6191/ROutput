# State of Execution
print(Sys.time())
memory.limit(8000)
#Load Libraries

library(data.table)
library(dplyr)
library(stringr)
library(splitstackshape)
library(tcltk)
library(rstudioapi)
library(Rserve)
Rserve()

get_scriptpath <- function() {
  # location of script can depend on how it was invoked:
  # source() and knit() put it in sys.calls()
  path <- NULL
  
  if(!is.null(sys.calls())) {
    path <- as.character(sys.call(1))[2] 
    # make sure we got a file that ends in .R, .Rmd or .Rnw
    if (grepl("..+\\.[R|Rmd|Rnw]", path, perl=TRUE, ignore.case = TRUE) )  {
      return(path)
    } else { 
      message("Obtained value for path does not end with .R, .Rmd or .Rnw: ", path)
    }
  } else{
    # Rscript and R -f put it in commandArgs
    args <- commandArgs(trailingOnly = FALSE)
  }
  return(path)
}


mypath <- get_scriptpath()

output_loc <- tk_choose.dir(getwd(),"Please choose the location to save the output files.")

varEntryDialog <- function(vars,
                           labels = vars,
                           fun = rep(list(as.character), length(vars)),
                           title = 'Variable Entry',
                           prompt = NULL) {
  require(tcltk)
  stopifnot(length(vars) == length(labels), length(labels) == length(fun))
  # Create a variable to keep track of the state of the dialog window:
  # done = 0; If the window is active
  # done = 1; If the window has been closed using the OK button
  # done = 2; If the window has been closed using the Cancel button or destroyed
  done <- tclVar(0)
  tt <- tktoplevel()
  tkwm.title(tt, title)
  entries <- list()
  tclvars <- list()
  # Capture the event "Destroy" (e.g. Alt-F4 in Windows) and when this happens,
  # assign 2 to done.
  tkbind(tt,"<Destroy>",function() tclvalue(done)<-2)
  for(i in seq_along(vars)) {
    tclvars[[i]] <- tclVar("Account_PRE.csv")
    entries[[i]] <- tkentry(tt, textvariable=tclvars[[i]])
  }
  doneVal <- as.integer(tclvalue(done))
  results <- list()
  reset <- function() {
    for(i in seq_along(entries)) {
      tclvalue(tclvars[[i]]) <<- ""
    }
  }
  reset.but <- tkbutton(tt, text="Reset", command=reset)
  cancel <- function() {
    tclvalue(done) <- 2
  }
  cancel.but <- tkbutton(tt, text='Cancel', command=cancel)
  submit <- function() {
    for(i in seq_along(vars)) {
      tryCatch( {
        results[[vars[[i]]]] <<- fun[[i]](tclvalue(tclvars[[i]]))
        tclvalue(done) <- 1
      },
      error = function(e) { tkmessageBox(message=geterrmessage()) },
      finally = { }
      )
    }
  }
  submit.but <- tkbutton(tt, text="Submit", command=submit)
  if(!is.null(prompt)) {
    tkgrid(tklabel(tt,text=prompt), columnspan=3, pady=5)
  }
  for(i in seq_along(vars)) {
    tkgrid(tklabel(tt, text=labels[i]), entries[[i]], pady=10, padx=10, columnspan=4)
  }
  tkgrid(submit.but, cancel.but, reset.but, pady=10, padx=10, columnspan=3)
  tkfocus(tt)
  # Do not proceed with the following code until the variable done is non-zero.
  # (But other processes can still run, i.e. the system is not frozen.)
  tkwait.variable(done)
  if(tclvalue(done) != 1) {
    results <- NULL
  }
  tkdestroy(tt)
  return(results)
}

var1 <- varEntryDialog(vars = 'Name', title = 'Output file name', prompt = 'Input name of the output file:')

output_name <- var1$Name


DIR <- dirname(mypath)
setwd(DIR)
setwd("..")
setwd(".//download")

#Input Data
for(i in 1:length(list.files())){
  if(tools::file_ext(list.files()[i])== "csv"){
    file <- read.csv(list.files()[i], sep="|",header=T,stringsAsFactors=FALSE,colClasses=c("LOS.APP.ID"="character"), nrows = 1)
    if((ncol(file) == 42 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
       (ncol(file) == 41 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
       (ncol(file) == 43 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") |
       (ncol(file) == 40 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID")){
      
      dz <- read.csv(list.files()[i], sep="|",header=T,colClasses=c("NULL", NA,"NULL","NULL","NULL","NULL","NULL","NULL","NULL",
                                                                    "NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL",
                                                                    "NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL",
                                                                    "NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL","NULL",
                                                                    "NULL","NULL","NULL","NULL","NULL"), row.names = NULL)
      dy <- read.csv(list.files()[i], sep="|",header=T,colClasses=c("CANDIDATE...ID"="character","LOS.APP.ID"="character"), row.names = NULL, nrows = 1)
      rm(file)
      break
    } else if (i == length(list.files())){
      print("No Account file found!!")
    }
  }
}

s<-function(d)
{
  
  PAY_RATIO_6M_INCREASE<-function(d)
  {
    d<-d[d$ACCT.TYPE=="Credit Card",]
    bad<-function(d)
    {
      l<-function(d,c1,c2)
      {
        count<-ifelse(c1>c2,1,0)
        return(count)
      }
      c1<-l(d,d$AMT.PAID...HIST_01/d$CUR.BAL...HIST_02,d$AMT.PAID...HIST_02/d$CUR.BAL...HIST_03)
      c2<-l(d,d$AMT.PAID...HIST_02/d$CUR.BAL...HIST_03,d$AMT.PAID...HIST_03/d$CUR.BAL...HIST_04)
      c3<-l(d,d$AMT.PAID...HIST_03/d$CUR.BAL...HIST_04,d$AMT.PAID...HIST_04/d$CUR.BAL...HIST_05)
      c4<-l(d,d$AMT.PAID...HIST_04/d$CUR.BAL...HIST_05,d$AMT.PAID...HIST_05/d$CUR.BAL...HIST_06)
      c5<-l(d,d$AMT.PAID...HIST_05/d$CUR.BAL...HIST_06,d$AMT.PAID...HIST_06/d$CUR.BAL...HIST_07)
      #c6<-l(d,d$AMT.PAID...HIST_06/d$CUR.BAL...HIST_07,d$AMT.PAID...HIST_07/d$CUR.BAL...HIST_08)
      
      c1[is.na(c1)]<-0
      c2[is.na(c2)]<-0
      c3[is.na(c3)]<-0
      c4[is.na(c4)]<-0
      c5[is.na(c5)]<-0
      #c6[is.na(c6)]<-0
      
      q<-c1+c2+c3+c4+c5
      return(q)
    }
    d$bb<-bad(d)
    act<-aggregate(d$bb,list(crd=d$KEY),sum)
    colnames(act) <- c("KEY", "PAY_RATIO_6M_INCREASE")
    return(act)
  }
  PAY_RATIO_6M_INCREASE<-PAY_RATIO_6M_INCREASE(d)
  
  
  PAY_RATIO_6M_DECREASE<-function(d)
  {
    d<-d[d$ACCT.TYPE=="Credit Card",]
    bad<-function(d)
    {
      l<-function(d,c1,c2)
      {
        count<-ifelse(c1<c2,1,0)
        return(count)
      }
      c1<-l(d,d$AMT.PAID...HIST_01/d$CUR.BAL...HIST_02,d$AMT.PAID...HIST_02/d$CUR.BAL...HIST_03)
      c2<-l(d,d$AMT.PAID...HIST_02/d$CUR.BAL...HIST_03,d$AMT.PAID...HIST_03/d$CUR.BAL...HIST_04)
      c3<-l(d,d$AMT.PAID...HIST_03/d$CUR.BAL...HIST_04,d$AMT.PAID...HIST_04/d$CUR.BAL...HIST_05)
      c4<-l(d,d$AMT.PAID...HIST_04/d$CUR.BAL...HIST_05,d$AMT.PAID...HIST_05/d$CUR.BAL...HIST_06)
      c5<-l(d,d$AMT.PAID...HIST_05/d$CUR.BAL...HIST_06,d$AMT.PAID...HIST_06/d$CUR.BAL...HIST_07)
      #c6<-l(d,d$AMT.PAID...HIST_06/d$CUR.BAL...HIST_07,d$AMT.PAID...HIST_07/d$CUR.BAL...HIST_08)
      
      
      
      c1[is.na(c1)]<-0
      c2[is.na(c2)]<-0
      c3[is.na(c3)]<-0
      c4[is.na(c4)]<-0
      c5[is.na(c5)]<-0
      #c6[is.na(c6)]<-0
      
      q<-c1+c2+c3+c4+c5
      return(q)
    }
    d$bb<-bad(d)
    act<-aggregate(d$bb,list(crd=d$KEY),sum)
    colnames(act) <- c("KEY", "PAY_RATIO_6M_DECREASE")
    return(act)
  }
  PAY_RATIO_6M_DECREASE<-PAY_RATIO_6M_DECREASE(d)
  
  q<-Reduce(function(x, y) merge(x, y,by=c("KEY"), all=TRUE),list(PAY_RATIO_6M_INCREASE,PAY_RATIO_6M_DECREASE))
  
  return(q)
}

rownumber <- nrow(dz)
column.names <- colnames(dy)

dataprep<-function(d)
{
  d<-concat.split.multiple(d, split.col="CUR.BAL...HIST", sep=",",drop=TRUE)
  d<-concat.split.multiple(d, split.col="AMT.PAID...HIST", sep=",",drop=TRUE)
  
  #d$current_balance_array<-paste0(d$CUR.BAL...HIST_01,",",d$CUR.BAL...HIST_02,",",d$CUR.BAL...HIST_03,",",d$CUR.BAL...HIST_04,",",d$CUR.BAL...HIST_05,",",d$CUR.BAL...HIST_06,",",d$CUR.BAL...HIST_07,",",d$CUR.BAL...HIST_08,",",d$CUR.BAL...HIST_09,",",d$CUR.BAL...HIST_10,",",d$CUR.BAL...HIST_11,",",d$CUR.BAL...HIST_12)
  
  #d$PAY_RATIO_6M_NUM<-(as.numeric(d$AMT.PAID...HIST_01)+as.numeric(d$AMT.PAID...HIST_02)+as.numeric(d$AMT.PAID...HIST_03)+as.numeric(d$AMT.PAID...HIST_04)+as.numeric(d$AMT.PAID...HIST_05)+as.numeric(d$AMT.PAID...HIST_06))
  #d$PAY_RATIO_6M_DEN<-(as.numeric(d$CUR.BAL...HIST_02)+as.numeric(d$CUR.BAL...HIST_03)+as.numeric(d$CUR.BAL...HIST_04)+as.numeric(d$CUR.BAL...HIST_05)+as.numeric(d$CUR.BAL...HIST_06)+as.numeric(d$CUR.BAL...HIST_07))
  
  d<-as.data.frame(d)
  return(d)
}


rm(dz)
rm(dy)
gc()

counter = 1
row_counter = 0
print("data reading over")

while(counter <= ceiling(rownumber/100000)){
  print(counter)
  for(i in 1:length(list.files())){
    if(tools::file_ext(list.files()[i])== "csv"){
      file <- read.csv(list.files()[i], sep="|",header=T,colClasses=c("CANDIDATE...ID"="character","LOS.APP.ID"="character"), nrows = 1)
      if((ncol(file) == 42 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
         (ncol(file) == 41 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") | 
         (ncol(file) == 43 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID") |
         (ncol(file) == 40 & colnames(file)[2] == "CANDIDATE...ID" & colnames(file)[3] == "LOS.APP.ID")){
        
        dff <- read.csv(list.files()[i], sep="|",header=T,colClasses=c("CANDIDATE...ID"="character","LOS.APP.ID"="character"), skip = 1 + row_counter, nrows = 100000)
        rm(file)
        break
      } else if (i == length(list.files())){
        print("No Account file found!!")
      }
    }
  }
  
  d <- mutate(dff, key1 = rownames(dff))
  colnames(d) <- column.names
  d$KEY<-paste(d$CREDT.RPT.ID,d$key1,sep="-")
  
  
  icounter=1
  jcounter=20000
  
  repeat 
  {
    
    if(icounter>nrow(d))
    {
      break
    }
    
    else
    {
      if (jcounter>nrow(d))
      {
        jcounter=nrow(d)
        print("Last Batch")
        print(icounter)
        print(jcounter)
        final<-d[icounter:jcounter,]
        revised<-dataprep(final)
        o<-s(revised)
        o<-merge(revised,o,by.y=c("KEY"),by.x=c("KEY"))
        o<-o[!duplicated(o),]
        o$key1<-NULL
        o$KEY<-NULL
        
        previous_wd <- getwd()
        setwd(output_loc)
        
        
        write.table(o,output_name,sep = "|",append = TRUE,row.names = FALSE,col.names = TRUE)
        icounter=icounter+20000
        jcounter=jcounter+20000
        
        
        
        setwd(previous_wd)
        
        print("End of Last Batch")
        print(Sys.time())
        
      } 
      else
      {		
        final<-d[icounter:jcounter,]
        revised<-dataprep(final)
        o<-s(revised)
        o<-merge(revised,o,by.y=c("KEY"),by.x=c("KEY"))
        o<-o[!duplicated(o),]
        o$key1<-NULL
        o$KEY<-NULL
        
        if(icounter==1)
        {
          print("First Batch")
          print(icounter)
          print(jcounter)
          
        
        previous_wd <- getwd()
        setwd(output_loc)
        
        
        write.table(o,output_name,sep = "|",append = TRUE,row.names = FALSE,col.names = TRUE)
        icounter=icounter+20000
        jcounter=jcounter+20000
        
        
        
        setwd(previous_wd)
        
          print("End of First Batch")
          print(Sys.time())
          
        }
        else
        {
          print("Intermediate Iteration")
          print(icounter)
          print(jcounter)
          
        previous_wd <- getwd()
        setwd(output_loc)
        
        
        write.table(o,output_name,sep = "|",append = TRUE,row.names = FALSE,col.names = TRUE)
          icounter=icounter+20000
          jcounter=jcounter+20000
          
		  
		  setwd(previous_wd)
          
          print("End of Iteration")
          print(Sys.time())
          
        }
        icounter=icounter+20000
        jcounter=jcounter+20000
      }
    }		
  }
  
  counter = counter + 1
  
  row_counter = row_counter + 100000
}

print(Sys.time())


