# State of Execution
print(Sys.time())
memory.limit(8000)

#Load Libraries

library(data.table)
library(dplyr)
library(stringr)
library(splitstackshape)
library(Rserve)
Rserve()

#Input Data
d<-read.table("C:/CHM/Script/Input/Account.csv",sep="|",header=T,colClasses=c("CANDIDATE...ID"="character","LOS.APP.ID"="character"))
d<-d[nchar(as.character(d$REPORTED.DATE...HIST))>0,]
d$X<-NULL

df<-read.table("C:/CHM/Script/Input/Inquiry.csv",sep="|",header=T,fill=T)
df$X<-NULL

df1<-read.table("C:/CHM/Script/Input/Ioi.csv",sep="|",header=T)
df1$X<-NULL

df2<-read.table("C:/CHM/Script/Input/Summary.csv",sep="|",header=T)
df2$X<-NULL

# Retro PR Date
date<-unique(df$RETRO.PR.DT)
date<-as.Date(paste(substr(date,1,2),'-',substr(date,4,5),'-',substr(date,7,10), sep = ''),  format="%d-%m-%Y")
df2$INQUIRY.DATE<-as.Date(df2$INQUIRY.DATE,"%d-%m-%Y")


# Data Preparation
d$DAS...HIST<-gsub("(.{3})", "\\1 ", d$DAS...HIST)
d$DPD...HIST<-gsub("(.{3})", "\\1 ", d$DPD...HIST)
d$ASSET.CLASS...HIST<-gsub("(.{3})", "\\1 ", d$ASSET.CLASS...HIST)
d<-concat.split.multiple(d, split.col="ASSET.CLASS...HIST", sep=" ")
d<-concat.split.multiple(d, split.col="DAS...HIST", sep=" ")

d$DPD_HIST_ORIGINAL<-d$DPD...HIST
d<-concat.split.multiple(d, split.col="DPD...HIST", sep=" ")

d<-concat.split.multiple(d, split.col="CUR.BAL...HIST", sep=",")  
d<-as.data.frame(d)
dpd<-c("DPD...HIST_01","DPD...HIST_02","DPD...HIST_03","DPD...HIST_04","DPD...HIST_05","DPD...HIST_06","DPD...HIST_07","DPD...HIST_08","DPD...HIST_09","DPD...HIST_10","DPD...HIST_11","DPD...HIST_12","DPD...HIST_13","DPD...HIST_14","DPD...HIST_15","DPD...HIST_16","DPD...HIST_17","DPD...HIST_18","DPD...HIST_19","DPD...HIST_20","DPD...HIST_21","DPD...HIST_22","DPD...HIST_23","DPD...HIST_24","DPD...HIST_25","DPD...HIST_26","DPD...HIST_27","DPD...HIST_28","DPD...HIST_29","DPD...HIST_30","DPD...HIST_31","DPD...HIST_32","DPD...HIST_33","DPD...HIST_34","DPD...HIST_35","DPD...HIST_36")


vars5<-names(d)%in%dpd

acl<-c("ASSET.CLASS...HIST_01","ASSET.CLASS...HIST_02","ASSET.CLASS...HIST_03","ASSET.CLASS...HIST_04","ASSET.CLASS...HIST_05","ASSET.CLASS...HIST_06","ASSET.CLASS...HIST_07","ASSET.CLASS...HIST_08","ASSET.CLASS...HIST_09","ASSET.CLASS...HIST_10","ASSET.CLASS...HIST_11","ASSET.CLASS...HIST_12","ASSET.CLASS...HIST_13","ASSET.CLASS...HIST_14","ASSET.CLASS...HIST_15","ASSET.CLASS...HIST_16","ASSET.CLASS...HIST_17","ASSET.CLASS...HIST_18","ASSET.CLASS...HIST_19","ASSET.CLASS...HIST_20","ASSET.CLASS...HIST_21","ASSET.CLASS...HIST_22","ASSET.CLASS...HIST_23","ASSET.CLASS...HIST_24","ASSET.CLASS...HIST_25","ASSET.CLASS...HIST_26","ASSET.CLASS...HIST_27","ASSET.CLASS...HIST_28","ASSET.CLASS...HIST_29","ASSET.CLASS...HIST_30","ASSET.CLASS...HIST_31","ASSET.CLASS...HIST_32","ASSET.CLASS...HIST_33","ASSET.CLASS...HIST_34","ASSET.CLASS...HIST_35","ASSET.CLASS...HIST_36")

vars6<-names(d)%in%acl

d[,vars6]<-apply(d[,vars6],2,FUN=as.character)
d[,vars5]<-apply(d[,vars5],2,FUN=as.character)

d[,vars6][d[,vars6]=="DDD"]<-0
d[,vars6][d[,vars6]=="L05"]<-1
d[,vars6][d[,vars6]=="L02"]<-91
d[,vars6][d[,vars6]=="L01"]<-0
d[,vars6][d[,vars6]=="L03"]<-361
d[,vars6][d[,vars6]=="L04"]<-361
d[,vars6][d[,vars6]=="XXX"]<-0
d[,vars6]<-apply(d[,vars6],2,FUN=as.numeric)
d[,vars5]<-apply(d[,vars5],2,FUN=as.numeric)


d$DPD...HIST_01<-ifelse(!is.na(d$DPD...HIST_01),d$DPD...HIST_01,d$ASSET.CLASS...HIST_01)
d$DPD...HIST_02<-ifelse(!is.na(d$DPD...HIST_02),d$DPD...HIST_02,d$ASSET.CLASS...HIST_02)
d$DPD...HIST_03<-ifelse(!is.na(d$DPD...HIST_03),d$DPD...HIST_03,d$ASSET.CLASS...HIST_03)
d$DPD...HIST_04<-ifelse(!is.na(d$DPD...HIST_04),d$DPD...HIST_04,d$ASSET.CLASS...HIST_04)
d$DPD...HIST_05<-ifelse(!is.na(d$DPD...HIST_05),d$DPD...HIST_05,d$ASSET.CLASS...HIST_05)
d$DPD...HIST_06<-ifelse(!is.na(d$DPD...HIST_06),d$DPD...HIST_06,d$ASSET.CLASS...HIST_06)
d$DPD...HIST_07<-ifelse(!is.na(d$DPD...HIST_07),d$DPD...HIST_07,d$ASSET.CLASS...HIST_07)
d$DPD...HIST_08<-ifelse(!is.na(d$DPD...HIST_08),d$DPD...HIST_08,d$ASSET.CLASS...HIST_08)
d$DPD...HIST_09<-ifelse(!is.na(d$DPD...HIST_09),d$DPD...HIST_09,d$ASSET.CLASS...HIST_09)
d$DPD...HIST_10<-ifelse(!is.na(d$DPD...HIST_10),d$DPD...HIST_10,d$ASSET.CLASS...HIST_10)
d$DPD...HIST_11<-ifelse(!is.na(d$DPD...HIST_11),d$DPD...HIST_11,d$ASSET.CLASS...HIST_11)
d$DPD...HIST_12<-ifelse(!is.na(d$DPD...HIST_12),d$DPD...HIST_12,d$ASSET.CLASS...HIST_12)
d$DPD...HIST_13<-ifelse(!is.na(d$DPD...HIST_13),d$DPD...HIST_13,d$ASSET.CLASS...HIST_13)

k<-function(d)
{

all_trades<-function(data.frame,ACCOUNT.STATUS)
{
act<-aggregate(d$ACCOUNT.STATUS,list(crd=d$CREDT.RPT.ID),table)
colnames(act) <- c("CREDT.RPT.ID", "ALL_TYPES_TRADES")
return(act)
}
ALL_TRADES<-all_trades(d,ACCOUNT.STATUS)

all_trades_types<-function(data.frame)
{
act<-aggregate(d$ACCT.TYPE,list(crd=d$CREDT.RPT.ID),table)
colnames(act) <- c("CREDT.RPT.ID", "TRADES")
return(act)
}
PDT_TYPE<-all_trades_types(d)


pcblgtthreethousand<-function(d)
{
pclgt3k<-function(d)
{





clgt3k<-function(x,y)
{
c<-ifelse(x>30&y>3000,1,0) 
return(c)
}
c1<-clgt3k(d$DPD...HIST_01,d$CUR.BAL...HIST_01)
c2<-clgt3k(d$DPD...HIST_02,d$CUR.BAL...HIST_02)
c3<-clgt3k(d$DPD...HIST_03,d$CUR.BAL...HIST_03)
c4<-clgt3k(d$DPD...HIST_04,d$CUR.BAL...HIST_04)
c5<-clgt3k(d$DPD...HIST_05,d$CUR.BAL...HIST_05)
c6<-clgt3k(d$DPD...HIST_06,d$CUR.BAL...HIST_06)
c7<-clgt3k(d$DPD...HIST_07,d$CUR.BAL...HIST_07)
c8<-clgt3k(d$DPD...HIST_08,d$CUR.BAL...HIST_08)
c9<-clgt3k(d$DPD...HIST_09,d$CUR.BAL...HIST_09)
c10<-clgt3k(d$DPD...HIST_10,d$CUR.BAL...HIST_10)
c11<-clgt3k(d$DPD...HIST_11,d$CUR.BAL...HIST_11)
c12<-clgt3k(d$DPD...HIST_12,d$CUR.BAL...HIST_12)
c1[is.na(c1)]<-0
c2[is.na(c2)]<-0
c3[is.na(c3)]<-0
c4[is.na(c4)]<-0
c5[is.na(c5)]<-0
c6[is.na(c6)]<-0
c7[is.na(c7)]<-0
c8[is.na(c8)]<-0
c9[is.na(c9)]<-0
c10[is.na(c10)]<-0
c11[is.na(c11)]<-0 
c12[is.na(c12)]<-0

q<-c1+c2+c3+c4+c5+c6+c7+c8+c9+c10+c11+c12
return(q)
}

d$gtthree<-pclgt3k(d)
act<-aggregate(d$gtthree,list(crd=d$CREDT.RPT.ID),sum) 
colnames(act) <- c("CREDT.RPT.ID", "DEL_GRTR_THIRTY_BALANCE_GRT_THREE_THOUSAND")
return(act)
}
DPDGRTR30_CURRBAL_GRTR3000<-pcblgtthreethousand(d)

PAYDEL_12MNT<-function(d)
{
bad<-function(d)
{
l<-function(d,c1,c2)
{
count<-ifelse(c1>30&(c1>c2),1,0)
return(count)
}
c1<-l(d,d$DPD...HIST_01,d$DPD...HIST_02)
c2<-l(d,d$DPD...HIST_02,d$DPD...HIST_03)
c3<-l(d,d$DPD...HIST_03,d$DPD...HIST_04)
c4<-l(d,d$DPD...HIST_04,d$DPD...HIST_05)
c5<-l(d,d$DPD...HIST_05,d$DPD...HIST_06)
c6<-l(d,d$DPD...HIST_06,d$DPD...HIST_07)
c7<-l(d,d$DPD...HIST_07,d$DPD...HIST_08)
c8<-l(d,d$DPD...HIST_08,d$DPD...HIST_09)
c9<-l(d,d$DPD...HIST_09,d$DPD...HIST_10)
c10<-l(d,d$DPD...HIST_10,d$DPD...HIST_11)
c11<-l(d,d$DPD...HIST_11,d$DPD...HIST_12)
c12<-l(d,d$DPD...HIST_12,d$DPD...HIST_13)
c1[is.na(c1)]<-0
c2[is.na(c2)]<-0
c3[is.na(c3)]<-0
c4[is.na(c4)]<-0
c5[is.na(c5)]<-0
c6[is.na(c6)]<-0
c7[is.na(c7)]<-0
c8[is.na(c8)]<-0
c9[is.na(c9)]<-0
c10[is.na(c10)]<-0
c11[is.na(c11)]<-0
c12[is.na(c12)]<-0


q<-c1+c2+c3+c4+c5+c6+c7+c8+c9+c10+c11+c12
return(q)

}
d$bb<-bad(d)
act<-aggregate(d$bb,list(crd=d$CREDT.RPT.ID),sum)
colnames(act) <- c("CREDT.RPT.ID", "DEL_INC_12_MNTH")
return(act)
}
INCREASE_12MNTH_DEL<-PAYDEL_12MNT(d)

# Merge resutls of all fucntions by credit report id
aggregate<-Reduce(function(x, y) merge(x, y, all=TRUE),list(ALL_TRADES,PDT_TYPE,DPDGRTR30_CURRBAL_GRTR3000,INCREASE_12MNTH_DEL))

#aggregate<-Reduce(function(x, y) merge(x, y,by=c("CREDT.RPT.ID"), all=TRUE), list(df1,aggregate))

return(aggregate)
# end of execution
print(Sys.time())
}

aggregate <- k(d)
aggregate<-as.data.frame(aggregate)

#aggregate<- merge(aggregate,df3,by="CREDT.RPT.ID")

#aggregate<-Reduce(function(x, y) merge(x, y,by=c("CREDT.RPT.ID"), all=TRUE), list(aggregate,df3,df4))

#names(aggregate)[1:22] <- c("CREDT-RPT-ID","STATUS","ERROR","CRIF HM Score","DESCRIPTION","PRI-NO-OF-ACCTS","PRI-ACTIVE-ACCTS","PRI-OVERDUE-ACCTS","PRI-CURRENT-BALANCE","PRI-SANCTIONED-AMOUNT","PRI-DISBURSED-AMOUNT","SEC-NO-OF-ACCTS","SEC-ACTIVE-ACCTS","SEC-OVERDUE-ACCTS","SEC-CURRENT-BALANCE","SEC-SANCTIONED-AMOUNT","SEC-DISBURSED-AMOUNT","NEW-ACCTS-IN-LAST-SIX-MONTHS","DELINQUENT-ACCTS-IN-LAST-SIX-MONTHS","AVERAGE-ACCT-AGE","CREDIT-HISTORY-LENGTH","NO-OF_INQUIRIES")

# write output data frame to flat file
write.table(aggregate,"C:/CHM/Script/Output/Inquiry_Post.csv",sep="|",row.names = FALSE)


gc()
rm(list=ls(all=TRUE))


